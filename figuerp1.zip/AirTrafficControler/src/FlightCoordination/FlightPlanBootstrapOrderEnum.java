package FlightCoordination;

public enum FlightPlanBootstrapOrderEnum {
	BY_REWARD, BY_EXPECT
}
