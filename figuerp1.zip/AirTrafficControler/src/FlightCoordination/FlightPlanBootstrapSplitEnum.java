package FlightCoordination;

public enum FlightPlanBootstrapSplitEnum {
	RANDOM_SPLIT, ORDERED_SPLIT
}
