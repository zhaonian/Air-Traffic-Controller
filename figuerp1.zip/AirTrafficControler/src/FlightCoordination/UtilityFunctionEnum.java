package FlightCoordination;

public enum UtilityFunctionEnum {
	DELTA, CDF
}
